package com.folksdevbank.folksdevbank;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FolksdevbankApplicationTests {

	@Test
	void contextLoads() {
	}

}
